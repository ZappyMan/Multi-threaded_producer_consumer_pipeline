HOW TO RUN
1. Compile the program by running the command "gcc -pthread -lm --std=gnu99 -o line_processor line_processor.c"
2. Run the compiled program with "./line_processor"
